package ua.yandex.collections;

/**
 *
 * @author Кирилл
 */
public class MyLinkedList implements MyList {

    private static class Node {

        private Object element;
        private Node next;

        Node() {
            next = null;
        }

        Node(Object e) {
            next = null;
            element = e;
        }

        Node(Object e, Node n) {
            element = e;
            next = n;
        }
        
    }

    private Node begin;
    private int size;

    MyLinkedList() {
        begin = null;
        size = 0;
    }

    private Node getEnd() {
        Node it = begin;
        if (it == null) {
            return it;
        }
        while (it.next != null) {
            it = it.next;
        }
        return it;
    }

    private void checkBoarderForAdd(int index) {
        if (index < 0 || index > size) {
            throw new IllegalListIndexException(
                    "index does not belong to [0,size]");
        }
    }

    private void checkBoarder(int index) {
        checkBoarderForAdd(index);
        if (index == size) {
            throw new IllegalListIndexException(
                    "index does not belong to [0,size-1]");
        }
    }

    @Override
    public void add(Object e) {
        if (size == 0) {
            begin = new Node(e);
        } else {
            Node end = getEnd();
            end.next = new Node(e);
        }
        size++;
    }

    @Override
    public void add(int index, Object e) {
        checkBoarderForAdd(index);
        if (index == 0) {
            Node temp = new Node(e, begin);
            begin = temp;
            size++;
        } else {
            Node it = begin;
            for (int number = index; number > 1; number--) {
                it = it.next;
            }
            if (it.next == null) {
                add(e);
            } else {
                Node temp = new Node(e, it.next);
                it.next = temp;
                size++;
            }
        }
    }

    @Override
    public void addAll(Object[] c) {
        for (Object e : c) {
            add(e);
        }
    }

    @Override
    public void addAll(int index, Object[] c) {
        checkBoarderForAdd(index);
        int number = index;
        for (Object e : c) {
            add(number++, e);
        }
    }

    @Override
    public Object get(int index) {
        checkBoarder(index);
        Node it = begin;
        int number = index;
        while (number > 0) {
            it = it.next;
            number--;
        }
        return it.element;
    }

    @Override
    public Object remove(int index) {
        checkBoarder(index);
        Node it = begin;
        int number = index;
        while (number > 1) {
            it = it.next;
            number--;
        }
        Object e;
        if (index == 0) {
            e = begin.element;
            begin = begin.next;
        } else {
            e = it.next.element;
            it.next = it.next.next;
        }
        size--;
        return e;
    }

    @Override
    public void set(int index, Object e) {
        checkBoarder(index);
        Node it = begin;
        int number = index;
        while (number > 0) {
            it = it.next;
            number--;
        }
        it.element = e;
    }

    @Override
    public int indexOf(Object o) {
        int index = 0;
        Node it = begin;
        while (it != null) {
            if (it.element == o) {
                return index;
            }
            index++;
            it = it.next;
        }
        return -1;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void clear() {
        begin = null;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public Object[] toArray() {
        Object[] tempList = new Object[size];
        Node it = begin;
        for (int i = 0; i < size; i++) {
            tempList[i] = it.element;
            it = it.next;
        }
        return tempList;
    }

    @Override
    public String toString() {
        StringBuffer stringBuff = new StringBuffer();
        stringBuff.append("[");
        Node it = begin;
        for (int i = 0; i < size; i++) {
            stringBuff.append(it.element.toString());
            it = it.next;
            if (i + 1 < size) {
                stringBuff.append(", ");
            }
        }
        stringBuff.append("]");
        return stringBuff.toString();
    }

    public void addFirst(Object e) {
        begin = new Node(e, begin);
    }

    public void addLast(Object e) {
        add(e);
    }

    public Object getFirst() {
        if (size == 0) {
            throw new IllegalListIndexException("List is empty");
        }
        return begin.element;
    }

    public Object getLast() {
        if (size == 0) {
            throw new IllegalListIndexException("List is empty");
        }
        Node end = getEnd();
        return end.element;
    }

    public Object removeFirst() {
        return remove(0);
    }

    public Object removeLast() {
        return remove(size - 1);
    }

}
